import React, { useEffect, useState } from 'react'
import { useNavigate, useSearchParams } from 'react-router-dom'
import { supabase } from '@/lib/supabase'
import { Loader2, CheckCircle, XCircle } from 'lucide-react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'

export default function AuthCallback() {
  const navigate = useNavigate()
  const [searchParams] = useSearchParams()
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState(false)

  useEffect(() => {
    const handleAuthCallback = async () => {
      try {
        const code = searchParams.get('code')
        
        if (code) {
          const { error } = await supabase.auth.exchangeCodeForSession(code)
          
          if (error) {
            setError(error.message)
          } else {
            setSuccess(true)
            // Redirect to dashboard after a brief delay
            setTimeout(() => {
              navigate('/', { replace: true })
            }, 2000)
          }
        } else {
          setError('Invalid verification link')
        }
      } catch (err) {
        setError('An error occurred during verification')
      } finally {
        setLoading(false)
      }
    }

    handleAuthCallback()
  }, [searchParams, navigate])

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <CardTitle className="text-2xl font-bold text-gray-900">
            {loading && 'Verifying Account...'}
            {success && 'Account Verified!'}
            {error && 'Verification Failed'}
          </CardTitle>
        </CardHeader>
        <CardContent className="text-center">
          {loading && (
            <div className="space-y-4">
              <Loader2 className="h-8 w-8 animate-spin mx-auto text-blue-600" />
              <p className="text-gray-600">Please wait while we verify your account...</p>
            </div>
          )}

          {success && (
            <div className="space-y-4">
              <CheckCircle className="h-12 w-12 text-green-600 mx-auto" />
              <div>
                <p className="text-green-600 font-medium">Your account has been verified successfully!</p>
                <p className="text-gray-600 text-sm mt-2">Redirecting you to the dashboard...</p>
              </div>
            </div>
          )}

          {error && (
            <div className="space-y-4">
              <XCircle className="h-12 w-12 text-red-600 mx-auto" />
              <div>
                <p className="text-red-600 font-medium">Verification failed</p>
                <p className="text-gray-600 text-sm mt-2">{error}</p>
              </div>
              <Button 
                onClick={() => navigate('/', { replace: true })}
                className="w-full"
              >
                Go to Sign In
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
