import React, { useState, useEffect } from 'react'
import { Board, Folder, Link, supabase } from '@/lib/supabase'
import { useAuth } from '@/contexts/AuthContext'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { 
  Plus, 
  MoreHorizontal, 
  Edit, 
  Trash2, 
  Share, 
  FolderPlus,
  ExternalLink,
  Globe
} from 'lucide-react'
import { cn } from '@/lib/utils'
import ShareDialog from '@/components/ShareDialog'

interface MainContentProps {
  selectedBoard: Board | null
}

interface FolderCardProps {
  folder: Folder
  onEdit: (folder: Folder) => void
  onDelete: (folderId: string) => void
  onShare: (folder: Folder) => void
}

interface LinkItemProps {
  link: Link
  onEdit: (link: Link) => void
  onDelete: (linkId: string) => void
  onShare: (link: Link) => void
}

function LinkItem({ link, onEdit, onDelete, onShare }: LinkItemProps) {
  const getFaviconUrl = (url: string) => {
    try {
      const domain = new URL(url).hostname
      return `https://www.google.com/s2/favicons?domain=${domain}&sz=16`
    } catch {
      return null
    }
  }

  return (
    <div className="group flex items-center p-3 border border-gray-200 rounded-lg bg-white hover:bg-blue-50 hover:border-blue-200 transition-all duration-200 cursor-pointer">
      <div className="flex items-center flex-1 min-w-0">
        <div className="flex-shrink-0 mr-3">
          {getFaviconUrl(link.url) ? (
            <img
              src={getFaviconUrl(link.url)}
              alt=""
              className="w-4 h-4"
              onError={(e) => {
                e.currentTarget.style.display = 'none'
                const nextElement = e.currentTarget.nextElementSibling as HTMLElement
                if (nextElement) nextElement.style.display = 'block'
              }}
            />
          ) : null}
          <Globe className="w-4 h-4 text-gray-400" style={{ display: 'none' }} />
        </div>
        
        <div className="flex-1 min-w-0">
          <div className="flex items-center space-x-2">
            <h4 className="text-sm font-medium text-gray-900 truncate">
              {link.title}
            </h4>
            <a
              href={link.url}
              target="_blank"
              rel="noopener noreferrer"
              className="opacity-0 group-hover:opacity-100 transition-opacity"
            >
              <ExternalLink className="w-3 h-3 text-gray-400 hover:text-gray-600" />
            </a>
          </div>
          {link.description && (
            <p className="text-xs text-gray-500 truncate mt-1">
              {link.description}
            </p>
          )}
          <p className="text-xs text-blue-600 truncate mt-1">
            {link.url}
          </p>
        </div>
      </div>

      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm" className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100">
            <MoreHorizontal className="h-3 w-3" />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end">
          <DropdownMenuItem onClick={() => onEdit(link)}>
            <Edit className="mr-2 h-4 w-4" />
            Edit
          </DropdownMenuItem>
          <DropdownMenuItem onClick={() => onShare(link)}>
            <Share className="mr-2 h-4 w-4" />
            Share
          </DropdownMenuItem>
          <DropdownMenuItem 
            onClick={() => onDelete(link.id)}
            className="text-red-600"
          >
            <Trash2 className="mr-2 h-4 w-4" />
            Delete
          </DropdownMenuItem>
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  )
}

function FolderCard({ folder, onEdit, onDelete, onShare }: FolderCardProps) {
  const [links, setLinks] = useState<Link[]>([])
  const [showAddLinkDialog, setShowAddLinkDialog] = useState(false)
  const [editingLink, setEditingLink] = useState<Link | null>(null)
  const [linkShareDialog, setLinkShareDialog] = useState<{ open: boolean; link: Link | null }>({ open: false, link: null })

  useEffect(() => {
    fetchLinks()
  }, [folder])

  const fetchLinks = async () => {
    try {
      const { data, error } = await supabase
        .from('links')
        .select('*')
        .eq('folder_id', folder.id)
        .order('position', { ascending: true })

      if (error) throw error
      setLinks(data || [])
    } catch (error) {
      console.error('Error fetching links:', error)
    }
  }

  const createLink = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    
    const formData = new FormData(e.currentTarget)
    const title = formData.get('title') as string
    const url = formData.get('url') as string
    const description = formData.get('description') as string

    try {
      const { data, error } = await supabase
        .from('links')
        .insert([
          {
            title,
            url,
            description: description || null,
            folder_id: folder.id,
            position: links.length,
          },
        ])
        .select()
        .single()

      if (error) throw error
      
      setLinks([...links, data])
      setShowAddLinkDialog(false)
    } catch (error) {
      console.error('Error creating link:', error)
    }
  }

  const updateLink = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!editingLink) return

    const formData = new FormData(e.currentTarget)
    const title = formData.get('title') as string
    const url = formData.get('url') as string
    const description = formData.get('description') as string

    try {
      const { data, error } = await supabase
        .from('links')
        .update({ 
          title, 
          url, 
          description: description || null,
          updated_at: new Date().toISOString() 
        })
        .eq('id', editingLink.id)
        .select()
        .single()

      if (error) throw error
      
      setLinks(links.map(l => l.id === editingLink.id ? data : l))
      setEditingLink(null)
    } catch (error) {
      console.error('Error updating link:', error)
    }
  }

  const deleteLink = async (linkId: string) => {
    try {
      const { error } = await supabase
        .from('links')
        .delete()
        .eq('id', linkId)

      if (error) throw error
      
      setLinks(links.filter(l => l.id !== linkId))
    } catch (error) {
      console.error('Error deleting link:', error)
    }
  }

  const handleShareLink = (link: Link) => {
    setLinkShareDialog({ open: true, link })
  }

  const addCurrentTabs = async () => {
    // Since we can't access browser tabs directly in a web app,
    // we'll show a simple dialog for users to paste URLs
    const urls = prompt('Paste URLs (one per line):')
    if (!urls) return

    const urlList = urls.split('\n').filter(url => url.trim())
    
    for (const url of urlList) {
      if (url.trim()) {
        try {
          // Try to get title from URL
          const title = new URL(url.trim()).hostname
          
          await supabase
            .from('links')
            .insert([
              {
                title,
                url: url.trim(),
                folder_id: folder.id,
                position: links.length,
              },
            ])
        } catch (error) {
          console.error('Error adding link:', error)
        }
      }
    }
    
    fetchLinks()
  }

  return (
    <Card className="h-fit shadow-soft hover:shadow-medium transition-all duration-200 animate-fade-in">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <div
              className="w-3 h-3 rounded-full"
              style={{ backgroundColor: folder.color }}
            />
            <CardTitle className="text-base">{folder.name}</CardTitle>
          </div>
          
          <div className="flex items-center space-x-1">
            <Button
              size="sm"
              variant="ghost"
              onClick={addCurrentTabs}
              className="h-6 px-2 text-xs"
            >
              Add URLs
            </Button>
            
            <Dialog open={showAddLinkDialog} onOpenChange={setShowAddLinkDialog}>
              <DialogTrigger asChild>
                <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                  <Plus className="h-3 w-3" />
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Add New Link</DialogTitle>
                </DialogHeader>
                <form onSubmit={createLink} className="space-y-4">
                  <div>
                    <Label htmlFor="title">Title</Label>
                    <Input id="title" name="title" placeholder="Enter link title" required />
                  </div>
                  <div>
                    <Label htmlFor="url">URL</Label>
                    <Input id="url" name="url" type="url" placeholder="https://example.com" required />
                  </div>
                  <div>
                    <Label htmlFor="description">Description (optional)</Label>
                    <Input id="description" name="description" placeholder="Enter description" />
                  </div>
                  <div className="flex justify-end space-x-2">
                    <Button type="button" variant="outline" onClick={() => setShowAddLinkDialog(false)}>
                      Cancel
                    </Button>
                    <Button type="submit">Add Link</Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-6 w-6 p-0">
                  <MoreHorizontal className="h-3 w-3" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuItem onClick={() => onEdit(folder)}>
                  <Edit className="mr-2 h-4 w-4" />
                  Edit
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => onShare(folder)}>
                  <Share className="mr-2 h-4 w-4" />
                  Share
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => onDelete(folder.id)}
                  className="text-red-600"
                >
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </div>
      </CardHeader>
      
      <CardContent className="pt-0">
        <div className="space-y-2">
          {links.map(link => (
            <LinkItem
              key={link.id}
              link={link}
              onEdit={setEditingLink}
              onDelete={deleteLink}
              onShare={handleShareLink}
            />
          ))}
          
          {links.length === 0 && (
            <div className="text-center py-6 text-gray-500">
              <p className="text-sm">No links yet</p>
              <p className="text-xs">Add your first link to get started</p>
            </div>
          )}
        </div>

        {/* Share Link Dialog */}
        <ShareDialog
          open={linkShareDialog.open}
          onOpenChange={(open) => setLinkShareDialog({ open, link: null })}
          resource={linkShareDialog.link}
          resourceType="link"
        />

        {/* Edit Link Dialog */}
        <Dialog open={!!editingLink} onOpenChange={() => setEditingLink(null)}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Edit Link</DialogTitle>
            </DialogHeader>
            <form onSubmit={updateLink} className="space-y-4">
              <div>
                <Label htmlFor="edit-title">Title</Label>
                <Input 
                  id="edit-title" 
                  name="title" 
                  defaultValue={editingLink?.title}
                  placeholder="Enter link title" 
                  required 
                />
              </div>
              <div>
                <Label htmlFor="edit-url">URL</Label>
                <Input 
                  id="edit-url" 
                  name="url" 
                  type="url"
                  defaultValue={editingLink?.url}
                  placeholder="https://example.com" 
                  required 
                />
              </div>
              <div>
                <Label htmlFor="edit-description">Description (optional)</Label>
                <Input 
                  id="edit-description" 
                  name="description" 
                  defaultValue={editingLink?.description || ''}
                  placeholder="Enter description" 
                />
              </div>
              <div className="flex justify-end space-x-2">
                <Button type="button" variant="outline" onClick={() => setEditingLink(null)}>
                  Cancel
                </Button>
                <Button type="submit">Save Changes</Button>
              </div>
            </form>
          </DialogContent>
        </Dialog>
      </CardContent>
    </Card>
  )
}

export default function MainContent({ selectedBoard }: MainContentProps) {
  const [folders, setFolders] = useState<Folder[]>([])
  const [loading, setLoading] = useState(false)
  const [showCreateFolderDialog, setShowCreateFolderDialog] = useState(false)
  const [editingFolder, setEditingFolder] = useState<Folder | null>(null)
  const [folderShareDialog, setFolderShareDialog] = useState<{ open: boolean; folder: Folder | null }>({ open: false, folder: null })

  useEffect(() => {
    if (selectedBoard) {
      fetchFolders()
    } else {
      setFolders([])
    }
  }, [selectedBoard])

  const fetchFolders = async () => {
    if (!selectedBoard) return

    setLoading(true)
    try {
      const { data, error } = await supabase
        .from('folders')
        .select('*')
        .eq('board_id', selectedBoard.id)
        .order('position', { ascending: true })

      if (error) throw error
      setFolders(data || [])
    } catch (error) {
      console.error('Error fetching folders:', error)
    } finally {
      setLoading(false)
    }
  }

  const createFolder = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!selectedBoard) return

    const formData = new FormData(e.currentTarget)
    const name = formData.get('name') as string
    const color = formData.get('color') as string

    try {
      const { data, error } = await supabase
        .from('folders')
        .insert([
          {
            name,
            color,
            board_id: selectedBoard.id,
            position: folders.length,
          },
        ])
        .select()
        .single()

      if (error) throw error
      
      setFolders([...folders, data])
      setShowCreateFolderDialog(false)
    } catch (error) {
      console.error('Error creating folder:', error)
    }
  }

  const updateFolder = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault()
    if (!editingFolder) return

    const formData = new FormData(e.currentTarget)
    const name = formData.get('name') as string
    const color = formData.get('color') as string

    try {
      const { data, error } = await supabase
        .from('folders')
        .update({ name, color, updated_at: new Date().toISOString() })
        .eq('id', editingFolder.id)
        .select()
        .single()

      if (error) throw error
      
      setFolders(folders.map(f => f.id === editingFolder.id ? data : f))
      setEditingFolder(null)
    } catch (error) {
      console.error('Error updating folder:', error)
    }
  }

  const deleteFolder = async (folderId: string) => {
    try {
      const { error } = await supabase
        .from('folders')
        .delete()
        .eq('id', folderId)

      if (error) throw error
      
      setFolders(folders.filter(f => f.id !== folderId))
    } catch (error) {
      console.error('Error deleting folder:', error)
    }
  }

  const handleShare = (folder: Folder) => {
    setFolderShareDialog({ open: true, folder })
  }

  if (!selectedBoard) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50">
        <div className="text-center">
          <FolderPlus className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">No board selected</h3>
          <p className="mt-1 text-sm text-gray-500">
            Select a board from the sidebar to view its folders and links.
          </p>
        </div>
      </div>
    )
  }

  return (
    <div className="flex-1 flex flex-col">
      {/* Header */}
      <div className="p-6 border-b border-gray-200 bg-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div
              className="w-4 h-4 rounded-full"
              style={{ backgroundColor: selectedBoard.color }}
            />
            <h1 className="text-2xl font-bold text-gray-900">{selectedBoard.name}</h1>
          </div>
          
          <Dialog open={showCreateFolderDialog} onOpenChange={setShowCreateFolderDialog}>
            <DialogTrigger asChild>
              <Button>
                <Plus className="mr-2 h-4 w-4" />
                Create Folder
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Create New Folder</DialogTitle>
              </DialogHeader>
              <form onSubmit={createFolder} className="space-y-4">
                <div>
                  <Label htmlFor="folder-name">Folder Name</Label>
                  <Input id="folder-name" name="name" placeholder="Enter folder name" required />
                </div>
                <div>
                  <Label htmlFor="folder-color">Color</Label>
                  <div className="flex space-x-2 mt-2">
                    {['#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#3B82F6', '#F97316'].map(color => (
                      <label key={color}>
                        <input
                          type="radio"
                          name="color"
                          value={color}
                          defaultChecked={color === '#8B5CF6'}
                          className="sr-only"
                        />
                        <div
                          className="w-6 h-6 rounded-full cursor-pointer border-2 border-transparent hover:border-gray-300"
                          style={{ backgroundColor: color }}
                        />
                      </label>
                    ))}
                  </div>
                </div>
                <div className="flex justify-end space-x-2">
                  <Button type="button" variant="outline" onClick={() => setShowCreateFolderDialog(false)}>
                    Cancel
                  </Button>
                  <Button type="submit">Create Folder</Button>
                </div>
              </form>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Content */}
      <div className="flex-1 p-6 bg-gray-50 overflow-y-auto">
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 lg:gap-6">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="h-64">
                <CardHeader>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-gray-200 rounded-full animate-pulse" />
                    <div className="h-4 bg-gray-200 rounded animate-pulse flex-1" />
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {[...Array(3)].map((_, j) => (
                      <div key={j} className="h-12 bg-gray-100 rounded animate-pulse" />
                    ))}
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : folders.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 lg:gap-6">
            {folders.map(folder => (
              <FolderCard
                key={folder.id}
                folder={folder}
                onEdit={setEditingFolder}
                onDelete={deleteFolder}
                onShare={handleShare}
              />
            ))}
          </div>
        ) : (
          <div className="flex items-center justify-center h-64">
            <div className="text-center">
              <FolderPlus className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">No folders yet</h3>
              <p className="mt-1 text-sm text-gray-500">
                Create your first folder to organize your bookmarks.
              </p>
              <Button 
                className="mt-4"
                onClick={() => setShowCreateFolderDialog(true)}
              >
                <Plus className="mr-2 h-4 w-4" />
                Create Folder
              </Button>
            </div>
          </div>
        )}
      </div>

      {/* Edit Folder Dialog */}
      <Dialog open={!!editingFolder} onOpenChange={() => setEditingFolder(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Edit Folder</DialogTitle>
          </DialogHeader>
          <form onSubmit={updateFolder} className="space-y-4">
            <div>
              <Label htmlFor="edit-folder-name">Folder Name</Label>
              <Input 
                id="edit-folder-name" 
                name="name" 
                defaultValue={editingFolder?.name}
                placeholder="Enter folder name" 
                required 
              />
            </div>
            <div>
              <Label htmlFor="edit-folder-color">Color</Label>
              <div className="flex space-x-2 mt-2">
                {['#8B5CF6', '#10B981', '#F59E0B', '#EF4444', '#3B82F6', '#F97316'].map(color => (
                  <label key={color}>
                    <input
                      type="radio"
                      name="color"
                      value={color}
                      defaultChecked={color === editingFolder?.color}
                      className="sr-only"
                    />
                    <div
                      className="w-6 h-6 rounded-full cursor-pointer border-2 border-transparent hover:border-gray-300"
                      style={{ backgroundColor: color }}
                    />
                  </label>
                ))}
              </div>
            </div>
            <div className="flex justify-end space-x-2">
              <Button type="button" variant="outline" onClick={() => setEditingFolder(null)}>
                Cancel
              </Button>
              <Button type="submit">Save Changes</Button>
            </div>
          </form>
        </DialogContent>
      </Dialog>

      {/* Share Folder Dialog */}
      <ShareDialog
        open={folderShareDialog.open}
        onOpenChange={(open) => setFolderShareDialog({ open, folder: null })}
        resource={folderShareDialog.folder}
        resourceType="folder"
      />
    </div>
  )
}
